@echo off
title AutoDiag Pro
color 0A
cd /d "%~dp0"
echo.
echo  ========================================
echo    AUTODIAG PRO - Agente v1.0
echo  ========================================
echo.
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js no esta instalado.
    echo  Descargalo desde: https://nodejs.org
    echo  Instala la version LTS y vuelve a abrir esto.
    pause
    exit /b 1
)
echo  [OK] Node.js instalado
if not exist node_modules\ws (
    echo  Instalando componente ws...
    npm install ws --save
)
echo  [OK] Todo listo - conectando...
echo.
node agent-lite.js
echo.
pause
