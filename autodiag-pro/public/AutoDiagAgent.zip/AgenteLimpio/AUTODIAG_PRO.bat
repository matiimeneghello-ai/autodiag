@echo off
title AutoDiag Pro - Agente v2.1
color 0A
cd /d "%~dp0"
echo.
echo  ==========================================
echo    AUTODIAG PRO - Agente v2.1
echo    VNCI Nano J2534 / RKW_VNCI_PT32
echo  ==========================================
echo.
echo  IMPORTANTE: Para PEGAR texto usa CLICK DERECHO
echo  (Ctrl+V no funciona en esta ventana)
echo.
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js no esta instalado.
    echo  Descargalo desde: https://nodejs.org
    pause
    exit /b 1
)
echo  [OK] Node.js instalado
if not exist node_modules\ws (
    echo  Instalando componentes...
    npm install ws serialport --save
    echo.
)
node agent-lite.js %*
echo.
pause
