@echo off
title AutoDiag Pro - Agente v2.0
color 0A
cd /d "%~dp0"
echo.
echo  ==========================================
echo    AUTODIAG PRO - Agente v2.0
echo    Diagnostico Multi-Modulo Real
echo  ==========================================
echo.

node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js no esta instalado.
    echo  Descargalo desde: https://nodejs.org
    echo  Instala la version LTS y vuelve a abrir esto.
    pause
    exit /b 1
)
echo  [OK] Node.js instalado

if not exist node_modules\ws (
    echo  Instalando componentes (solo la primera vez)...
    npm install ws serialport --save
    echo  [OK] Componentes instalados
    echo.
)

echo  Buscando interfaz J2534 / ELM327...
echo  (Conecta tu interfaz ANTES de continuar)
echo.
node agent-lite.js %*
echo.
echo  Agente cerrado.
pause
